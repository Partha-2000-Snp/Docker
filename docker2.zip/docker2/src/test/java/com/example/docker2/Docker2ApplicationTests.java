package com.example.docker2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Docker2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
